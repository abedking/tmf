#Tabchi NMS
install :
git clone https://github.com/puryanms/tnms/ && cd tnms && chmod +x bot && ./bot install && ./bot create
 
 run :
 ./bot 1
